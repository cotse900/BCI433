
#######################################################################################################
##   IBM Rational Developer for i - Activation Kit Readme                                            ##
##   last updated: 25-May-2013                                                                       ##
#######################################################################################################


By default, Rational Developer for i is installed with a permanent license for the 
product level and trial licenses for the individual main features. To convert the license for a 
particular feature to a permanent license, you need to install the Activation Kit for the feature 
using the Manage Licenses wizard in IBM Installation Manager.


=========================================
Installation instructions
=========================================

To install the feature Activation Kit:

1. If you received the activation kit as an electronic image, extract the contents of this .zip file  
   to a new folder.
   
2. Note the name and location of the activation kit .jar file within the folder or disk. 

3. Start IBM Installation Manager.

4. On the main page, click Manage Licenses.

5. Select particular feature the license is for and click Import Activation Kit.

6. Click Next. Browse to the path for the activation kit; then select the activation kit .jar file and 
   click Open. Details for the selected license are shown.

7. Click Next. The Licenses page displays the product license agreements.  Read the terms and click 
   I accept the terms in the license agreements. 

8. Click Next. The Summary page displays the license name, vendor, and license type.

9. Click Finish.

10. The activation kit with its permanent license key is imported to the product. The Manage Licenses 
   wizard indicates whether the import is successful.
